"""
BioChem.scrapers.molsoft - Modul untuk mengakses data properti molekul dari Molsoft

Modul ini menyediakan kelas untuk mengambil dan memproses data properti molekuler
dari situs web Molsoft (https://www.molsoft.com/mprop/), sebuah web tools untuk 
prediksi berbagai properti molekuler penting dalam pengembangan obat.

Kelas utama:
- MolsoftScraper: Mengambil dan menganalisis data properti molekuler

Contoh penggunaan:
```python
from BioChem import MolsoftScraper

# Inisialisasi scraper dengan 4 worker
scraper = MolsoftScraper(max_workers=4)

# Mengambil data untuk satu SMILES
result = scraper.run("CC(=O)OC1=CC=CC=C1C(=O)O")  # Aspirin
print(result)

# Mengambil data untuk beberapa SMILES sekaligus
smiles_list = ["CC(=O)OC1=CC=CC=C1C(=O)O", "CCO", "C1CCCCC1"]
results = scraper.run(smiles_list)
print(results)
```
"""

from rdkit import Chem
from rdkit.Chem import AllChem
import requests
import re
import pandas as pd
from bs4 import BeautifulSoup
from typing import Union, List
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.console import Console
from rich.logging import RichHandler
import logging

# Konfigurasi rich logging
console = Console()
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(console=console, show_time=True, markup=True)],
)
logger = logging.getLogger("molsoft_scraper")


class MolsoftScraper:
    """
    Kelas untuk mengambil data properti molekuler dari situs Molsoft.
    
    Kelas ini menyediakan fungsionalitas untuk mengirimkan SMILES ke Molsoft
    dan mendapatkan hasil prediksi properti molekuler dalam bentuk DataFrame.
    Properti yang diambil termasuk LogP, LogS, PSA, dan parameter lain yang
    relevan untuk pengembangan obat.
    
    Attributes:
        BASE_URL (str): URL dasar Molsoft untuk properti molekuler.
        max_workers (int): Jumlah thread worker maksimum untuk pemrosesan paralel.
    """
    
    BASE_URL = "https://www.molsoft.com/mprop/"

    def __init__(self, max_workers: int = 4):
        """
        Inisialisasi MolsoftScraper.
        
        Args:
            max_workers (int, optional): Jumlah thread worker maksimum. Default 4.
        """
        self.max_workers = max_workers

    def smiles_to_molblock(self, smiles: str) -> str:
        """
        Mengonversi SMILES ke format MolBlock dengan koordinat 2D.
        
        Args:
            smiles (str): String SMILES yang valid.
            
        Returns:
            str: Representasi MolBlock dari SMILES.
            
        Raises:
            ValueError: Jika SMILES tidak valid.
        """
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            raise ValueError(f"SMILES tidak valid: {smiles}")
        AllChem.Compute2DCoords(mol)
        mol_block = Chem.MolToMolBlock(mol)
        return mol_block.replace("RDKit", "MOLSOFT", 1)

    def fetch_html(self, smiles: str) -> str:
        """
        Mengirimkan data SMILES ke Molsoft dan mendapatkan respon HTML.
        
        Args:
            smiles (str): String SMILES yang valid.
            
        Returns:
            str: Konten HTML dari respons.
            
        Raises:
            ConnectionError: Jika gagal terhubung ke server.
        """
        mol_block = self.smiles_to_molblock(smiles)
        payload = {
            "p": "",
            "sm": "",
            "jme_mol": mol_block,
            "act": "Search",
            "Calc": "Calculate Properties"
        }

        headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        }

        response = requests.post(self.BASE_URL, data=payload, headers=headers)
        if response.status_code != 200:
            raise ConnectionError(f"Gagal mengambil data untuk {smiles}, status: {response.status_code}")
        return response.text

    def parse_html(self, html: str, smiles: str) -> pd.DataFrame:
        """
        Mengurai HTML dari hasil Molsoft dan mengekstrak informasi properti molekuler.
        
        Args:
            html (str): Konten HTML dari respons.
            smiles (str): SMILES yang digunakan dalam permintaan.
            
        Returns:
            pandas.DataFrame: DataFrame berisi properti molekuler.
        """
        soup = BeautifulSoup(html, "html.parser")
        b_tags = soup.find_all("b")

        def get_value(key):
            tag = next((b for b in b_tags if key in b.text), None)
            if tag:
                return tag.next_sibling.strip() if tag.next_sibling else None
            return None

        logs_text = get_value("MolLogS :")
        logs_val = None
        if logs_text:
            match = re.search(r"([-\d.]+)\s+\(in Log", logs_text)
            logs_val = match.group(1) if match else None

        bbb_score_text = get_value("BBB Score :")
        bbb_score = None
        if bbb_score_text:
            match = re.search(r"^\s*([-\d.]+)", bbb_score_text)
            bbb_score = match.group(1) if match else None

        data = {
            "SMILES": [smiles],
            "Molecular formula": [get_value("Molecular formula:")],
            "Molecular weight": [get_value("Molecular weight:")],
            "HBA": [get_value("Number of HBA:")],
            "HBD": [get_value("Number of HBD:")],
            "MolLogP": [get_value("MolLogP :")],
            "MolLogS": [logs_val],
            "MolPSA": [get_value("MolPSA :")],
            "MolVol": [get_value("MolVol :")],
            "pKa": [get_value("pKa of most Basic/Acidic group :")],
            "BBB Score": [bbb_score],
            "Number of stereo centers": [get_value("Number of stereo centers:")]
        }

        return pd.DataFrame(data)



    def process_single(self, smiles: str) -> pd.DataFrame:
        """
        Memproses satu SMILES dan mendapatkan data properti molekulernya.
        
        Args:
            smiles (str): String SMILES yang valid.
            
        Returns:
            pandas.DataFrame: DataFrame berisi properti molekuler.
        """
        try:
            html = self.fetch_html(smiles)
            df = self.parse_html(html, smiles)
            console.log(f"[green]✔ Sukses:[/] {smiles}")
            return df
        except Exception as e:
            console.log(f"[red]✖ Gagal:[/] {smiles} | {e}")
            return pd.DataFrame()


    def run(self, smiles_input: Union[str, List[str]]) -> pd.DataFrame:
        """
        Menjalankan proses pengambilan data properti molekuler untuk SMILES yang diberikan.
        
        Args:
            smiles_input (str or list): SMILES tunggal atau daftar SMILES.
            
        Returns:
            pandas.DataFrame: DataFrame berisi properti molekuler untuk semua SMILES.
        """
        smiles_list = [smiles_input] if isinstance(smiles_input, str) else smiles_input
        logger.info(f"[cyan]🔍 Memulai scraping {len(smiles_list)} SMILES...[/]")

        results = []
        total = len(smiles_list)
        completed = 0

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
            transient=True
        ) as progress:

            task_id = progress.add_task(f"[yellow]⏳ Memproses SMILES... [0/{total}]", total=total)

            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {
                    executor.submit(self.process_single, smiles): smiles
                    for smiles in smiles_list
                }

                for future in as_completed(futures):
                    result = future.result()
                    completed += 1

                    if not result.empty:
                        results.append(result)

                    # Update progress bar & description
                    progress.update(task_id, advance=1, description=f"[yellow]⏳ Memproses SMILES... [{completed}/{total}]")

        final_df = pd.concat(results, ignore_index=True)
        logger.info(f"[bold green]🏁 Selesai![/] Total berhasil: {len(final_df)} / {len(smiles_list)}")
        return final_df