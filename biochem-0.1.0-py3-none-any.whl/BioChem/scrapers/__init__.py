"""
BioChem.scrapers - Modul scrapers untuk BioChem

Modul ini berisi berbagai kelas scraper untuk mengambil data dari berbagai sumber web
yang relevan dengan biokimia dan kimia medisinal.

Modul yang tersedia:
- admetlab: Mengambil data properti ADMET senyawa kimia dari ADMETlab
- knapsack: Mengambil data metabolit dari KNApSAcK database
- protox: Mengambil data toksisitas senyawa kimia dari ProTox
- molsoft: Mengambil data properti molekuler dari Molsoft
"""

from BioChem.scrapers.admetlab import AdmetLabScraper
from BioChem.scrapers.knapsack import KnapsackScraper
from BioChem.scrapers.protox import ProtoxScraper
from BioChem.scrapers.molsoft import MolsoftScraper

__all__ = [
    'AdmetLabScraper',
    'KnapsackScraper',
    'ProtoxScraper',
    'MolsoftScraper'
] 