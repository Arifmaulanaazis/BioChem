"""
BioChem.scrapers.knapsack - Modul untuk mengakses database KNApSAcK

Modul ini menyediakan kelas untuk mengambil dan memproses data metabolit dari 
KNApSAcK database (https://www.knapsackfamily.com), sebuah database yang berisi 
informasi tentang metabolit sekunder tanaman.

Kelas utama:
- KnapsackScraper: Kelas untuk mengambil data dari KNApSAcK database

Contoh penggunaan:
```python
from BioChem import KnapsackScraper

# Mencari data berdasarkan nama tanaman
scraper = KnapsackScraper(search_type="all", keyword="Ginkgo Biloba", max_workers=5)
results = scraper.search()
print(results)

# Ekspor hasil ke file Excel
results.to_excel("Ginkgo_Biloba_Data.xlsx", index=False)
```
"""

import requests
from bs4 import BeautifulSoup
from urllib.parse import quote
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.logging import RichHandler
from rich.progress import Progress, SpinnerColumn, BarColumn, TimeElapsedColumn, TextColumn
import logging

# Setup logger
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler()]
)
log = logging.getLogger("knapsack")


class KnapsackScraper:
    """
    Kelas untuk mengambil data metabolit dari KNApSAcK database.
    
    KnapsackScraper memungkinkan pencarian metabolit berdasarkan berbagai kriteria seperti
    nama spesies tanaman, nama keluarga tanaman, rumus molekul, atau berbagai parameter lainnya,
    dan mendapatkan informasi terperinci tentang metabolit yang ditemukan.
    
    Attributes:
        BASE_URL (str): URL dasar hasil pencarian KNApSAcK.
        DETAIL_URL (str): URL dasar halaman detail KNApSAcK.
        search_type (str): Tipe pencarian (all, name, formula, mass, cid).
        keyword (str): Kata kunci pencarian.
        max_workers (int): Jumlah thread maksimum untuk pemrosesan paralel.
    """
    
    BASE_URL = "https://www.knapsackfamily.com/knapsack_core/result.php"
    DETAIL_URL = "https://www.knapsackfamily.com/knapsack_core/information.php?word="

    def __init__(self, search_type: str = "all", keyword: str = "", max_workers: int = 5):
        """
        Inisialisasi KnapsackScraper.
        
        Args:
            search_type (str, optional): Tipe pencarian yang digunakan (all, name, formula, mass, cid).
                Default "all".
            keyword (str, optional): Kata kunci pencarian. Default "".
            max_workers (int, optional): Jumlah thread maksimum untuk pemrosesan paralel. Default 5.
        """
        self.search_type = search_type
        self.keyword = keyword
        self.max_workers = max_workers

    def build_url(self) -> str:
        """
        Membangun URL pencarian berdasarkan tipe pencarian dan kata kunci.
        
        Returns:
            str: URL lengkap untuk pencarian dengan parameter yang diberikan.
        """
        encoded_keyword = quote(self.keyword)
        return f"{self.BASE_URL}?sname={self.search_type}&word={encoded_keyword}"

    def fetch_html(self, url: str) -> str:
        """
        Mengambil konten HTML dari URL yang diberikan.
        
        Args:
            url (str): URL yang akan diambil.
            
        Returns:
            str: Konten HTML dari URL.
            
        Raises:
            requests.exceptions.RequestException: Jika terjadi kesalahan saat mengambil URL.
        """
        log.debug(f"🔗 Fetching URL: {url}")
        response = requests.get(url)
        response.raise_for_status()
        return response.text

    def parse_main_table(self, html: str) -> pd.DataFrame:
        """
        Mengurai tabel utama dari hasil pencarian KNApSAcK.
        
        Args:
            html (str): Konten HTML halaman hasil pencarian.
            
        Returns:
            pandas.DataFrame: DataFrame berisi data dari tabel hasil pencarian.
        """
        soup = BeautifulSoup(html, "html.parser")
        table = soup.find("table")

        if not table:
            log.warning("⚠️  Tabel tidak ditemukan.")
            return pd.DataFrame()

        data = []
        data.append(["C_ID", "CAS_ID", "Metabolite", "Molecular_Formula", "Mw", "Organism or InChIKey etc."])
        rows = table.find_all("tr")

        for row in rows:
            cols = row.find_all("td")
            data.append([col.get_text(strip=True) for col in cols])

        return pd.DataFrame(data[1:], columns=data[0])


    def parse_organism_table(self, organism_table) -> list:
        """
        Mengurai tabel organisme dari halaman detail KNApSAcK.
        
        Args:
            organism_table (BeautifulSoup): Elemen tabel organisme.
            
        Returns:
            list: Daftar organisme yang mengandung senyawa ini.
        """
        organisms = []
        rows = organism_table.find_all("tr")[1:]
        for row in rows:
            cols = row.find_all("td")
            if len(cols) >= 4:
                organisms.append({
                    "kingdom": cols[0].get_text(strip=True),
                    "family": cols[1].get_text(strip=True),
                    "species": cols[2].get_text(strip=True),
                    "reference": cols[3].get_text(strip=True)
                })
        return organisms

    def get_detail_by_cid(self, cid: str) -> dict:
        """
        Mengambil detail senyawa berdasarkan C_ID KNApSAcK.
        
        Args:
            cid (str): ID senyawa KNApSAcK (C_ID).
            
        Returns:
            dict: Data detail senyawa dalam bentuk dictionary.
        """
        try:
            url = f"{self.DETAIL_URL}{quote(cid)}"
            html = self.fetch_html(url)
            soup = BeautifulSoup(html, "html.parser")

            detail = {
                "C_ID": cid,
                "InChIKey": None,
                "InChICode": None,
                "SMILES": None,
                "image_url": None,
                "Organism": None
            }

            table = soup.find("table", class_="d3")
            if table:
                for row in table.find_all("tr"):
                    header = row.find("th", class_="inf")
                    if not header:
                        continue

                    label = header.get_text(strip=True)
                    td = row.find("td")
                    value = td.get_text(strip=True) if td else None

                    if label == "InChIKey":
                        detail["InChIKey"] = value
                    elif label == "InChICode":
                        detail["InChICode"] = value
                    elif label == "SMILES":
                        detail["SMILES"] = value
                    elif label == "Organism":
                        organism_table = row.find_next("table")
                        if organism_table:
                            detail["Organism"] = self.parse_organism_table(organism_table)

            # Gambar
            image_tag = soup.find("img", attrs={"property": "image"})
            if image_tag and image_tag.get("src"):
                detail["image_url"] = f"https://www.knapsackfamily.com{image_tag['src']}"

            log.debug(f"✅ Detail OK: {cid}")
            return detail

        except Exception as e:
            log.error(f"❌ Gagal mengambil detail {cid}: {e}")
            return {
                "C_ID": cid, "InChIKey": None, "InChICode": None,
                "SMILES": None, "image_url": None, "Organism": None
            }

    def search(self) -> pd.DataFrame:
        """
        Melakukan pencarian dan mengambil detail untuk semua hasil.
        
        Metode ini:
        1. Melakukan pencarian berdasarkan keyword dan search_type
        2. Mengambil data dari tabel hasil pencarian
        3. Mengambil detail untuk setiap senyawa yang ditemukan
        4. Menggabungkan data dasar dan detail ke dalam satu DataFrame
        
        Returns:
            pandas.DataFrame: DataFrame berisi semua data metabolit dari hasil pencarian.
        """
        url = self.build_url()
        log.info(f"🔍 Mencari data untuk keyword: '{self.keyword}' (tipe: {self.search_type})")
        html = self.fetch_html(url)
        df_main = self.parse_main_table(html)

        if df_main.empty:
            log.warning("😢 Tidak ada hasil ditemukan.")
            return df_main

        log.info(f"📄 {len(df_main)} entri ditemukan. Mengambil detail...")

        detail_list = []
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            transient=True
        ) as progress:
            task = progress.add_task("[cyan]Mengambil detail C_ID...", total=len(df_main))

            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {executor.submit(self.get_detail_by_cid, cid): cid for cid in df_main["C_ID"]}
                for future in as_completed(futures):
                    detail = future.result()
                    detail_list.append(detail)
                    progress.advance(task)

        df_detail = pd.DataFrame(detail_list)
        df_merged = pd.merge(df_main, df_detail, on="C_ID", how="left")

        log.info("✅ Semua data selesai diambil.")
        return df_merged 