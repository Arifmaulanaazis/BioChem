"""
BioChem.scrapers.admetlab - Modul untuk mengakses data ADMETlab

Modul ini menyediakan kelas untuk mengambil dan memproses data properti ADMET
(Absorption, Distribution, Metabolism, Excretion, and Toxicity) senyawa kimia
dari situs web ADMETlab (https://admetlab3.scbdd.com).

Kelas utama:
- AdmetLabScraper: Mengambil dan menganalisis data properti ADMET senyawa kimia

Contoh penggunaan:
```python
from BioChem import AdmetLabScraper

# Inisialisasi scraper dengan 4 worker dan batch size 50
scraper = AdmetLabScraper(max_workers=4, max_batch_size=50)

# Mengambil data untuk satu SMILES
results = scraper.run("CC(=O)OC1=CC=CC=C1C(=O)O")  # Aspirin
print(results)

# Mengambil data untuk banyak SMILES sekaligus
smiles_list = ["CC(=O)OC1=CC=CC=C1C(=O)O", "CCO", "C1CCCCC1"]
results = scraper.run(smiles_list)
print(results)
```
"""

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from io import StringIO
import pandas as pd
import logging
from rich.logging import RichHandler
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from concurrent.futures import ThreadPoolExecutor, as_completed
import re

# Setup rich logging
console = Console()

# Setup FileHandler untuk file log
file_handler = logging.FileHandler("logs.log", encoding="utf-8")
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(logging.Formatter(
    fmt="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="[%Y-%m-%d %H:%M:%S]"
))

logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(console=console, show_time=True, markup=True), file_handler],
)
logger = logging.getLogger("admetlab_scraper")


class AdmetLabScraper:
    """
    Kelas untuk mengambil data properti ADMET dari situs ADMETlab.
    
    Kelas ini menyediakan fungsionalitas untuk mengirimkan SMILES ke ADMETlab
    dan mendapatkan hasil prediksi properti ADMET dalam bentuk DataFrame.
    
    Attributes:
        BASE_URL (str): URL dasar ADMETlab.
        INDEX_URL (str): URL halaman utama ADMETlab Screening.
        POST_URL (str): URL endpoint untuk mengirim permintaan SMILES.
        max_workers (int): Jumlah thread worker maksimum untuk pemrosesan paralel.
        max_batch_size (int): Jumlah maksimum SMILES dalam satu batch.
    """
    
    BASE_URL = "https://admetlab3.scbdd.com"
    INDEX_URL = f"{BASE_URL}/server/screening"
    POST_URL = f"{BASE_URL}/server/screeningCal"

    def __init__(self, max_workers: int = 4, max_batch_size: int = 100):
        """
        Inisialisasi AdmetLabScraper.
        
        Args:
            max_workers (int, optional): Jumlah thread worker maksimum. Default 4.
            max_batch_size (int, optional): Jumlah maksimum SMILES dalam satu batch. Default 100.
            
        Raises:
            ValueError: Jika max_batch_size tidak dalam rentang 1-100.
        """
        if max_batch_size > 100:
            raise ValueError("⚠️ Maksimum batch size adalah 100.")
        if max_batch_size < 1:
            raise ValueError("⚠️ Minimum batch size adalah 1.")

        self.max_workers = max_workers
        self.max_batch_size = max_batch_size


    def _get_csrf_token(self, session):
        """
        Mengambil token CSRF dari halaman ADMETlab.
        
        Args:
            session (requests.Session): Sesi HTTP yang aktif.
            
        Returns:
            str: Token CSRF yang diperoleh.
            
        Raises:
            ValueError: Jika token CSRF tidak ditemukan.
        """
        response = session.get(self.INDEX_URL, verify=False)
        soup = BeautifulSoup(response.text, 'html.parser')
        token_input = soup.find('input', {'name': 'csrfmiddlewaretoken'})
        if not token_input:
            raise ValueError("CSRF token tidak ditemukan.")
        return token_input['value']

    def _submit_smiles(self, session, smiles_text, token):
        """
        Mengirimkan SMILES ke ADMETlab.
        
        Args:
            session (requests.Session): Sesi HTTP yang aktif.
            smiles_text (str): Teks SMILES yang akan dikirim.
            token (str): Token CSRF yang valid.
            
        Returns:
            requests.Response: Respons HTTP dari permintaan yang dikirim.
        """
        headers = {
            'Referer': self.INDEX_URL,
            'Origin': self.BASE_URL,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
            'Content-Type': 'application/x-www-form-urlencoded',
        }
        data = {
            'csrfmiddlewaretoken': token,
            'smiles-list': smiles_text,
            'method': '2'
        }
        return session.post(self.POST_URL, headers=headers, data=data, verify=False)

    def _parse_summary(self, soup):
        """
        Mengurai ringkasan hasil dari halaman hasil ADMETlab.
        
        Args:
            soup (BeautifulSoup): Objek BeautifulSoup dari halaman hasil.
            
        Returns:
            dict: Ringkasan hasil yang berisi jumlah molekul.
        """
        summary = {}
        success = 0
        invalid = 0

        # Cari semua card title
        cards = soup.find_all('div', class_='info-card')

        for card in cards:
            title = card.find('h5', class_='card-title')
            if title:
                title_text = title.get_text(strip=True).lower()
                number_tag = card.find('h6')
                if number_tag:
                    number = int(number_tag.get_text(strip=True))
                    if 'success' in title_text:
                        summary['success_molecules'] = number
                        success += number
                    elif 'invalid' in title_text:
                        summary['invalid_molecules'] = number
                        invalid += number
                    elif 'total' in title_text:
                        summary['total_molecules'] = number
                        
        return summary

    def _get_csv_url(self, soup):
        """
        Mendapatkan URL unduhan file CSV dari halaman hasil ADMETlab.
        
        Args:
            soup (BeautifulSoup): Objek BeautifulSoup dari halaman hasil.
            
        Returns:
            str: URL lengkap untuk mengunduh file CSV hasil.
        """
        scripts = soup.find_all('script')
        for script in scripts:
            if script.string:
                match = re.search(r'window\.open\(["\'](.*?)\.csv["\']\)', script.string)
                if match:
                    csv_url = match.group(1) + ".csv"
                    return urljoin(self.BASE_URL, csv_url)
            

    def _process_batch(self, smiles_batch):
        """
        Memproses batch SMILES dan mendapatkan hasilnya.
        
        Args:
            smiles_batch (list): Daftar SMILES yang akan diproses.
            
        Returns:
            pandas.DataFrame: DataFrame berisi hasil batch SMILES.
        """
        session = requests.Session()
        try:
            token = self._get_csrf_token(session)
            smiles_text = "\r\n".join(smiles_batch)
            response = self._submit_smiles(session, smiles_text, token)
            soup = BeautifulSoup(response.text, 'html.parser')

            summary = self._parse_summary(soup)
            logger.info(f"[green]✔ Batch {len(smiles_batch)} molekul. Invalid: {summary.get('invalid_molecules')}[/]")

            csv_url = self._get_csv_url(soup)
            csv_response = session.get(csv_url)
            df = pd.read_csv(StringIO(csv_response.text))
            return df
        except Exception as e:
            logger.error(f"[red]✖ Gagal proses batch: {e}[/]")
            return pd.DataFrame()

    def run(self, smiles_input):
        """
        Menjalankan proses pengambilan data ADMET untuk SMILES yang diberikan.
        
        Args:
            smiles_input (str or list): SMILES tunggal atau daftar SMILES.
            
        Returns:
            pandas.DataFrame: DataFrame berisi hasil prediksi properti ADMET.
            
        Raises:
            TypeError: Jika smiles_input bukan string atau list.
        """
        if isinstance(smiles_input, str):
            smiles_list = [smiles_input]
        elif isinstance(smiles_input, list):
            smiles_list = smiles_input
        else:
            raise TypeError("SMILES harus berupa string atau list of string.")

        chunks = [smiles_list[i:i + self.max_batch_size] for i in range(0, len(smiles_list), self.max_batch_size)]
        logger.info(f"[cyan]🔍 Memulai scraping {len(smiles_list)} SMILES dalam {len(chunks)} batch (maks {self.max_batch_size}/batch)...[/]")

        results = []
        total = len(chunks)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
            transient=True
        ) as progress:

            task_id = progress.add_task(f"[yellow]⏳ Memproses batch... [0/{total}]", total=total)

            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = {executor.submit(self._process_batch, batch): i for i, batch in enumerate(chunks)}

                for future in as_completed(futures):
                    result = future.result()
                    if not result.empty:
                        results.append(result)
                    progress.update(task_id, advance=1,
                        description=f"[yellow]⏳ Memproses batch... [{progress.tasks[0].completed}/{total}]")

        final_df = pd.concat(results, ignore_index=True) if results else pd.DataFrame()
        logger.info(f"[bold green]🏁 Selesai![/] Total molekul berhasil: {len(final_df)}")
        return final_df 