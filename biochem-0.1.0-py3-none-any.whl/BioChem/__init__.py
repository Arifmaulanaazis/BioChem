"""
BioChem - Library untuk Bioinformatika dan Kimia Komputasi

BioChem adalah pustaka terintegrasi yang menyediakan berbagai alat untuk
menganalisis, memperoleh, dan memproses data biokimia dari berbagai sumber web.

Modul yang tersedia:
- admetlab: Mengambil data properti ADMET senyawa kimia dari ADMETlab
- knapsack: Mengambil data metabolit dari KNApSAcK database
- protox: Mengambil data toksisitas senyawa kimia dari ProTox
- molsoft: Mengambil data properti molekuler dari Molsoft

Penggunaan dasar:
```python
import BioChem

# Menggunakan scraper ADMETlab
scraper = BioChem.AdmetLabScraper()
results = scraper.run(["CC(=O)OC1=CC=CC=C1C(=O)O", "CCC"])
print(results)

# Menggunakan scraper KNApSAcK
knapsack = BioChem.KnapsackScraper(search_type="all", keyword="Ginkgo Biloba")
results = knapsack.search()
print(results)
```
"""

# Mengimpor semua modul
from BioChem.scrapers.admetlab import AdmetLabScraper
from BioChem.scrapers.knapsack import KnapsackScraper
from BioChem.scrapers.protox import ProtoxScraper
from BioChem.scrapers.molsoft import MolsoftScraper

# Versi library
__version__ = '0.1.0'

# Nama modul yang akan diekspos ke pengguna
__all__ = [
    'AdmetLabScraper', 
    'KnapsackScraper', 
    'ProtoxScraper', 
    'MolsoftScraper'
] 